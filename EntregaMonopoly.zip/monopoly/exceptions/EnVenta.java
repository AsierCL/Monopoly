package monopoly.exceptions;

public class EnVenta extends PropiedadException {
    public EnVenta() {  
        super("La casilla no puede comprarse.");
    }
}

