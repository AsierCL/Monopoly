package monopoly.exceptions;

public class EdificioVenta extends PropiedadException {
    public EdificioVenta() {
        super("No cuentas con tantos edificios de este tipo.");
    }
    
}
