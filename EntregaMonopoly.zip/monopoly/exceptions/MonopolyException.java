package monopoly.exceptions;

public class MonopolyException extends Exception {
    public MonopolyException(String mensaje) {
        super(mensaje);
    }
}




