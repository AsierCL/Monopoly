package monopoly.exceptions;

public class ConstruirHotel extends PropiedadException {
    public ConstruirHotel() {
        super("Debes construir un hotel.");
    } 
}
    
