package monopoly.exceptions;

public class TratosException extends MonopolyException {
    public TratosException(String mensaje){
        super(mensaje);
    }
    
}
