package monopoly.exceptions;

public class AvatarNombre extends JuegoException {
    public AvatarNombre() {
        super("No existe el avatar.");
    }
}
