package monopoly.exceptions;

public class CasillaDeshipotecada extends PropiedadException {
    public CasillaDeshipotecada() {
        super("La casilla no está hipotecada.");
    }
}
