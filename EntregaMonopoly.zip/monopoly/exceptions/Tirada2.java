package monopoly.exceptions;

public class Tirada2 extends JuegoException {
    public Tirada2() {
        super("Debes tirar antes.");
    }
}
