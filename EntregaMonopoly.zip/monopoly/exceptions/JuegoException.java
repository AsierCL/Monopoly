package monopoly.exceptions;

public class JuegoException extends MonopolyException {
    public JuegoException(String mensaje) {
        super(mensaje);
    }
     
}
