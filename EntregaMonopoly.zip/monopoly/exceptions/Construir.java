package monopoly.exceptions;

public class Construir extends JuegoException{
    public Construir() {
        super("No puedes construir aquí");
    }
}
