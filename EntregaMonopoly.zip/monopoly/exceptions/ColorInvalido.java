package monopoly.exceptions;

public class ColorInvalido extends PropiedadException {
    public ColorInvalido() {
        super("Color inválido.");
    }
}