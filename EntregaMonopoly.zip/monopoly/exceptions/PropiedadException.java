package monopoly.exceptions;

public class PropiedadException extends MonopolyException {
    public PropiedadException(String mensaje) {
        super(mensaje);
    }
}
