package monopoly.edificios;

public class Casa extends Edificio {
    public Casa() {
    }
}