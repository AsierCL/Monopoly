package monopoly.edificios;

public class Pista extends Edificio {
    public Pista(){
    }
}
