package monopoly.edificios;

public class Piscina extends Edificio {
    public Piscina(){
    }
}
