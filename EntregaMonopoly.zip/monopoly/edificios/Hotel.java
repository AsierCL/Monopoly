package monopoly.edificios;

public class Hotel extends Edificio{
    public Hotel(){
    }
}
